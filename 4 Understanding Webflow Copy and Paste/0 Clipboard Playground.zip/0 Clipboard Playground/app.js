document.addEventListener("DOMContentLoaded", main);

function main() {
    // Grab DOM elements
    const elements = getElements();

    // Register event handlers
    setupPasteHandler(elements);
    setupTestClipboardButton(elements);
    setupResetButton(elements);
    setupJSONButton(elements);

    // Initial UI State
    resetUI(elements);
}

// ---------------------------
// DOM ELEMENTS & UI HANDLERS
// ---------------------------

function getElements() {
    return {
        pasteBox: document.getElementById("pasteBox"),
        testClipboardButton: document.getElementById("testClipboard"),
        resetButton: document.getElementById("reset"),
        JSONButton: document.getElementById("JSON"),
        banner: document.getElementById("banner"),
        payloadType: document.getElementById("payloadType"),
        payloadOutput: document.getElementById("payloadOutput"),
        imageContainer: document.getElementById("imageContainer")
    };
}

function setupPasteHandler({ pasteBox, banner, payloadType, payloadOutput }) {
    pasteBox.addEventListener("paste", function (event) {
        event.preventDefault();
        navigator.clipboard.readText().then(text => {
            if (!text.trim()) {
                updateBanner(banner, "red", "Error: Clipboard has data, but it's not plain text. Please click 'Test Clipboard'.");
            } else {
                updatePayload(payloadType, payloadOutput, "text/plain", text);
                updateBanner(banner, "amber", "Payload Analysis");
            }
        }).catch(() => {
            updateBanner(banner, "red", "Error: Unable to access clipboard. Check permissions.");
        });
    });
}

function setupTestClipboardButton(elements) {
    elements.testClipboardButton.addEventListener("click", () => analyzeClipboardPayload(elements));
}

function setupResetButton({ resetButton }) {
    resetButton.addEventListener("click", () => resetUI(getElements()));
}

function setupJSONButton({ JSONButton }) {
    JSONButton.addEventListener("click", pasteJSON);
}
// ---------------------------
// UI LOGIC
// ---------------------------

function updateBanner(banner, type, message) {
    banner.className = `banner ${type}`;
    banner.textContent = message;
}

function updatePayload(payloadType, payloadOutput, type, content) {
    payloadType.textContent = type;
    payloadOutput.textContent = content.length > 750 ? content.substring(0, 750) + "… [truncated]" : content;
}

function resetUI({ pasteBox, banner, payloadType, payloadOutput, imageContainer }) {
    updateBanner(banner, "green", "Ready for the next test!");
    pasteBox.value = "";
    payloadType.textContent = "None";
    payloadOutput.textContent = "None";
    imageContainer.innerHTML = "";
}

function pasteJSON() {
    const jsonObject = { message: "Hello" };
    const jsonString = JSON.stringify(jsonObject, null, 2);

    function onCopy(e) {
        e.preventDefault();
        e.clipboardData.setData("application/json", jsonString);
        //e.clipboardData.setData("text/plain", jsonString); // optional fallback
        document.removeEventListener("copy", onCopy); // clean up
        alert("✅ JSON copied to clipboard as application/json!");
    }

    document.addEventListener("copy", onCopy);
    document.execCommand("copy");
}


// ---------------------------
// CLIPBOARD ANALYSIS LOGIC
// ---------------------------

function displayClipboardItem({ type, content }, container) {
    const wrapper = document.createElement("div");
    wrapper.classList.add("clipboard-item");

    if (type === "application/json") {
        // JSONEditor requires a container element
        const jsonContainer = document.createElement("div");
        jsonContainer.style.height = "300px";
        jsonContainer.style.border = "1px solid #ddd";
        jsonContainer.style.marginBottom = "1em";
        wrapper.appendChild(jsonContainer);

        try {
            const parsedJSON = JSON.parse(content);
            const editor = new JSONEditor(jsonContainer, {
                mode: 'view',
                mainMenuBar: false
            });
            editor.set(parsedJSON);
        } catch (err) {
            wrapper.innerHTML = `<strong>Error parsing JSON:</strong> ${err.message}`;
        }

    } else {
        wrapper.innerHTML = `
            <strong>Type:</strong> ${type}<br>
            <pre>${content}</pre>
            <hr>
        `;
    }

    container.appendChild(wrapper);
}


async function analyzeClipboardPayload({ banner, payloadType, payloadOutput, imageContainer }) {
    imageContainer.innerHTML = ""; // Clear previous

    try {
        const clipboardItems = await navigator.clipboard.read();
        const totalItems = clipboardItems.length;

        if (totalItems === 0) {
            updateBanner(banner, "red", "Error: Clipboard is empty.");
            return;
        }

        updateBanner(banner, "amber", `Payload Analysis (${totalItems} item${totalItems > 1 ? 's' : ''})`);
        payloadType.textContent = `${totalItems} item${totalItems > 1 ? 's' : ''}`;
        payloadOutput.textContent = "See items below ↓";

        for (const item of clipboardItems) {
            for (const type of item.types) {
                const blob = await item.getType(type);

                if (type.startsWith("image/")) {
                    const imgURL = URL.createObjectURL(blob);
                    const img = document.createElement("img");
                    img.src = imgURL;
                    img.alt = "Clipboard Image";
                    img.style.maxWidth = "300px";
                    imageContainer.appendChild(img);
                } else {
                    const text = await blob.text();

                    displayClipboardItem({ type, content: text }, imageContainer);
                }
            }
        }

    } catch (error) {
        updateBanner(banner, "red", `Error: ${error.message}`);
    }
}
